import axios from 'axios';

// 创建axios实例
const request = axios.create({
  baseURL: '/api', // 使用相对路径，通过Vite代理转发
  timeout: 30000, // 增加到30秒
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器
request.interceptors.request.use(
  (config) => {
    console.log('发送请求:', config.method.toUpperCase(), config.url);
    // 获取token并添加到请求头
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    console.error('请求配置错误:', error);
    return Promise.reject(error);
  }
);

// 响应拦截器
request.interceptors.response.use(
  (response) => {
    console.log('请求成功:', response.config.url);
    return response.data;
  },
  (error) => {
    console.error('请求失败:', error.config?.url || '未知URL');
    console.error('错误状态码:', error.response?.status);
    console.error('错误数据:', error.response?.data);
    
    // 处理token过期或无效
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
      return Promise.reject(new Error('登录已过期，请重新登录'));
    }
    
    // 处理权限不足
    if (error.response?.status === 403) {
      return Promise.reject(new Error('没有权限执行此操作'));
    }
    
    // 处理服务器错误
    if (error.response?.status >= 500) {
      return Promise.reject(new Error('服务器内部错误，请稍后再试'));
    }
    
    // 处理网络错误
    if (!error.response) {
      return Promise.reject(new Error('网络错误，请检查您的网络连接或后端服务是否正常运行'));
    }
    
    // 其他错误
    const errorMessage = error.response?.data?.message || '请求失败';
    return Promise.reject(new Error(errorMessage));
  }
);

export default request;
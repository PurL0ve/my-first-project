import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { getDoctors, getDoctorDetail } from '../services/doctor';
import { createAppointment } from '../services/appointment';
import './Appointment.css';

const Appointment = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // 可选的时间段
  const availableTimeSlots = [
    '09:00-10:00', '10:00-11:00', '11:00-12:00',
    '14:00-15:00', '15:00-16:00', '16:00-17:00'
  ];
  
  // 获取URL中的医生ID
  const getDoctorIdFromUrl = () => {
    const params = new URLSearchParams(location.search);
    return params.get('doctorId');
  };
  
  // 加载医生列表
  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const response = await getDoctors();
        setDoctors(response.data || []);
      } catch (error) {
        console.error('获取医生列表失败:', error);
        setError('获取医生列表失败，请稍后再试');
      }
    };
    
    fetchDoctors();
  }, []);
  
  // 从URL参数设置选中的医生
  useEffect(() => {
    const doctorId = getDoctorIdFromUrl();
    if (doctorId) {
      const selectDoctorFromUrl = async () => {
        try {
          const doctor = await getDoctorDetail(doctorId);
          setSelectedDoctor(doctor);
        } catch (error) {
          console.error('获取医生详情失败:', error);
          setError('获取医生详情失败，请稍后再试');
        }
      };
      
      selectDoctorFromUrl();
    }
  }, [location.search]);
  
  // 处理医生选择变化
  const handleDoctorChange = async (e) => {
    const doctorId = e.target.value;
    if (doctorId) {
      try {
        const doctor = await getDoctorDetail(doctorId);
        setSelectedDoctor(doctor);
        setError('');
      } catch (error) {
        console.error('获取医生详情失败:', error);
        setError('获取医生详情失败，请稍后再试');
      }
    } else {
      setSelectedDoctor(null);
    }
  };
  
  // 提交预约表单
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // 表单验证
    if (!selectedDoctor || !date || !timeSlot || !symptoms) {
      setError('请填写所有必填信息');
      return;
    }
    
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // 准备预约数据
      const appointmentData = {
        doctorId: selectedDoctor.id,
        date,
        timeSlot,
        symptoms
      };
      
      // 提交预约
      await createAppointment(appointmentData);
      
      setSuccess('预约成功！');
      
      // 重置表单（可选）
      // setDate('');
      // setTimeSlot('');
      // setSymptoms('');
      
      // 延迟导航到我的预约页面
      setTimeout(() => {
        navigate('/my-appointments');
      }, 1500);
      
    } catch (error) {
      console.error('创建预约失败:', error);
      setError('预约失败，请稍后再试');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="appointment-container">
      <h2>预约挂号</h2>
      
      {error && <div className="error-message">{error}</div>}
      {success && <div className="success-message">{success}</div>}
      
      <form onSubmit={handleSubmit} className="appointment-form">
        {/* 医生选择 */}
        <div className="form-group">
          <label htmlFor="doctor">选择医生</label>
          <select
            id="doctor"
            value={selectedDoctor?.id || ''}
            onChange={handleDoctorChange}
            required
          >
            <option value="">请选择医生</option>
            {doctors.map(doctor => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.name} - {doctor.department} - {doctor.title}
              </option>
            ))}
          </select>
        </div>
        
        {/* 显示选中医生的信息 */}
        {selectedDoctor && (
          <div className="doctor-info">
            <h3>{selectedDoctor.name}</h3>
            <p><strong>科室:</strong> {selectedDoctor.department}</p>
            <p><strong>职称:</strong> {selectedDoctor.title}</p>
            <p><strong>专长:</strong> {selectedDoctor.specialty}</p>
            <p><strong>经验:</strong> {selectedDoctor.experience}</p>
            <p><strong>简介:</strong> {selectedDoctor.description}</p>
          </div>
        )}
        
        {/* 日期选择 */}
        <div className="form-group">
          <label htmlFor="date">预约日期</label>
          <input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            min={new Date().toISOString().split('T')[0]}
            required
          />
        </div>
        
        {/* 时间段选择 */}
        <div className="form-group">
          <label htmlFor="timeSlot">预约时间段</label>
          <select
            id="timeSlot"
            value={timeSlot}
            onChange={(e) => setTimeSlot(e.target.value)}
            required
          >
            <option value="">请选择时间段</option>
            {availableTimeSlots.map(slot => (
              <option key={slot} value={slot}>{slot}</option>
            ))}
          </select>
        </div>
        
        {/* 症状描述 */}
        <div className="form-group">
          <label htmlFor="symptoms">症状描述</label>
          <textarea
            id="symptoms"
            value={symptoms}
            onChange={(e) => setSymptoms(e.target.value)}
            placeholder="请简要描述您的症状"
            rows="4"
            required
          ></textarea>
        </div>
        
        {/* 提交按钮 */}
        <button type="submit" className="submit-button" disabled={loading}>
          {loading ? '提交中...' : '确认预约'}
        </button>
      </form>
    </div>
  );
};

export default Appointment;
import React, { useState, useEffect } from 'react';
import { getUserAppointments, cancelAppointment } from '../services/appointment';
import './MyAppointments.css';

const MyAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('all');
  
  // 获取用户预约列表
  useEffect(() => {
    const fetchAppointments = async () => {
      setLoading(true);
      try {
        const params = status !== 'all' ? { status } : {};
        const response = await getUserAppointments(params);
        setAppointments(response.data || []);
      } catch (error) {
        console.error('获取预约列表失败:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchAppointments();
  }, [status]);
  
  // 取消预约
  const handleCancel = async (id) => {
    if (window.confirm('确定要取消这个预约吗？')) {
      try {
        await cancelAppointment(id);
        // 重新加载预约列表
        const response = await getUserAppointments(status !== 'all' ? { status } : {});
        setAppointments(response.data || []);
      } catch (error) {
        console.error('取消预约失败:', error);
      }
    }
  };
  
  // 格式化日期
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="my-appointments-container">
      <h2>我的预约</h2>
      
      {/* 状态筛选 */}
      <div className="status-filter">
        <button
          className={status === 'all' ? 'active' : ''}
          onClick={() => setStatus('all')}
        >
          全部
        </button>
        <button
          className={status === 'pending' ? 'active' : ''}
          onClick={() => setStatus('pending')}
        >
          待就诊
        </button>
        <button
          className={status === 'completed' ? 'active' : ''}
          onClick={() => setStatus('completed')}
        >
          已完成
        </button>
        <button
          className={status === 'cancelled' ? 'active' : ''}
          onClick={() => setStatus('cancelled')}
        >
          已取消
        </button>
      </div>
      
      {/* 预约列表 */}
      {loading ? (
        <div className="loading">加载中...</div>
      ) : (
        <div className="appointments-list">
          {appointments.length > 0 ? (
            appointments.map(appointment => (
              <div key={appointment.id} className="appointment-item">
                <div className="appointment-header">
                  <h3>{appointment.doctor?.name || '未知医生'}</h3>
                  <span className={`status status-${appointment.status}`}>
                    {appointment.status === 'pending' && '待就诊'}
                    {appointment.status === 'completed' && '已完成'}
                    {appointment.status === 'cancelled' && '已取消'}
                  </span>
                </div>
                
                <div className="appointment-details">
                  <p><strong>科室:</strong> {appointment.doctor?.department || '未知'}</p>
                  <p><strong>时间:</strong> {formatDate(appointment.date + 'T' + appointment.timeSlot.split('-')[0])}</p>
                  <p><strong>症状:</strong> {appointment.symptoms}</p>
                </div>
                
                {appointment.status === 'pending' && (
                  <div className="appointment-actions">
                    <button 
                      className="cancel-button"
                      onClick={() => handleCancel(appointment.id)}
                    >
                      取消预约
                    </button>
                    <a 
                      href={`/queue?appointmentId=${appointment.id}`}
                      className="queue-button"
                    >
                      查看排队状态
                    </a>
                  </div>
                )}
                
                {appointment.status === 'completed' && (
                  <div className="appointment-actions">
                    <a 
                      href={`/medical-records?appointmentId=${appointment.id}`}
                      className="record-button"
                    >
                      查看病例
                    </a>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="no-appointments">暂无预约记录</div>
          )}
        </div>
      )}
    </div>
  );
};

export default MyAppointments;
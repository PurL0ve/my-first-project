import React, { useState, useEffect } from 'react';
import { getUserInfo, updateUserInfo } from '../services/auth';
import './UserInfo.css';

const UserInfo = () => {
  const [userInfo, setUserInfo] = useState({
    username: '',
    phone: '',
    email: '',
  });
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  
  // 获取用户信息
  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const data = await getUserInfo();
        setUserInfo(data);
      } catch (error) {
        console.error('获取用户信息失败:', error);
      }
    };
    
    fetchUserInfo();
  }, []);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserInfo(prev => ({ ...prev, [name]: value }));
    setSuccess('');
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await updateUserInfo(userInfo);
      setSuccess('更新成功');
      setEditing(false);
    } catch (error) {
      console.error('更新失败:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="user-info-container">
      <h2>个人信息</h2>
      {success && <div className="success-message">{success}</div>}
      
      <form onSubmit={handleSubmit} className="user-info-form">
        <div className="form-group">
          <label>用户名</label>
          <input
            type="text"
            name="username"
            value={userInfo.username}
            onChange={handleChange}
            disabled={!editing}
          />
        </div>
        
        <div className="form-group">
          <label>手机号码</label>
          <input
            type="tel"
            name="phone"
            value={userInfo.phone}
            onChange={handleChange}
            disabled={!editing}
          />
        </div>
        
        <div className="form-group">
          <label>电子邮箱</label>
          <input
            type="email"
            name="email"
            value={userInfo.email}
            onChange={handleChange}
            disabled={!editing}
          />
        </div>
        
        <div className="form-actions">
          {editing ? (
            <>
              <button type="submit" disabled={loading}>
                {loading ? '保存中...' : '保存'}
              </button>
              <button type="button" onClick={() => setEditing(false)}>
                取消
              </button>
            </>
          ) : (
            <button type="button" onClick={() => setEditing(true)}>
              编辑
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default UserInfo;
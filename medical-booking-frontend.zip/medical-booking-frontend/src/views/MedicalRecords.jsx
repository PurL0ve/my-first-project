import React, { useState, useEffect } from 'react';
import { getUserMedicalRecords, getMedicalRecordDetail } from '../services/medicalRecord';
import './MedicalRecords.css';

const MedicalRecords = () => {
  const [records, setRecords] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [loading, setLoading] = useState(false);
  
  // 获取用户病例列表
  useEffect(() => {
    const fetchRecords = async () => {
      setLoading(true);
      try {
        // 在实际应用中，这里应该从API获取真实数据
        // const response = await getUserMedicalRecords();
        
        // 模拟数据
        const mockRecords = [
          {
            id: '1',
            doctorName: '张医生',
            department: '内科',
            visitDate: '2023-06-15T10:30:00',
            diagnosis: '普通感冒',
            status: 'completed'
          },
          {
            id: '2',
            doctorName: '李医生',
            department: '儿科',
            visitDate: '2023-05-20T14:00:00',
            diagnosis: '儿童发热',
            status: 'completed'
          },
          {
            id: '3',
            doctorName: '王医生',
            department: '皮肤科',
            visitDate: '2023-04-10T09:00:00',
            diagnosis: '过敏性皮炎',
            status: 'completed'
          }
        ];
        
        setRecords(mockRecords);
      } catch (error) {
        console.error('获取病例列表失败:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchRecords();
  }, []);
  
  // 查看病例详情
  const handleViewDetail = async (id) => {
    setLoading(true);
    try {
      // 在实际应用中，这里应该从API获取真实数据
      // const data = await getMedicalRecordDetail(id);
      
      // 模拟数据
      const record = records.find(r => r.id === id);
      const mockDetail = {
        ...record,
        symptoms: '患者主诉头痛、发热、咳嗽三天，无痰',
        examination: '体温38.5℃，咽部充血，双侧扁桃体Ⅰ度肿大，双肺呼吸音粗',
        treatment: '1. 休息，多喝水\n2. 布洛芬缓释胶囊 0.3g 口服 每日2次\n3. 复方感冒灵颗粒 1袋 冲服 每日3次',
        advice: '若症状加重或持续不缓解，请及时复诊',
        doctorNotes: '患者一般情况良好，给予对症治疗，嘱患者注意休息'
      };
      
      setSelectedRecord(mockDetail);
    } catch (error) {
      console.error('获取病例详情失败:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // 关闭详情
  const handleCloseDetail = () => {
    setSelectedRecord(null);
  };
  
  // 格式化日期
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="medical-records-container">
      <h2>病例查询</h2>
      
      {/* 病例列表 */}
      {loading && !selectedRecord ? (
        <div className="loading">加载中...</div>
      ) : (
        <div className="records-list">
          {records.length > 0 ? (
            <table className="records-table">
              <thead>
                <tr>
                  <th>医生</th>
                  <th>科室</th>
                  <th>就诊日期</th>
                  <th>诊断结果</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {records.map(record => (
                  <tr key={record.id}>
                    <td>{record.doctorName}</td>
                    <td>{record.department}</td>
                    <td>{formatDate(record.visitDate)}</td>
                    <td>{record.diagnosis}</td>
                    <td>
                      <button 
                        className="view-button"
                        onClick={() => handleViewDetail(record.id)}
                      >
                        查看详情
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="no-records">暂无病例记录</div>
          )}
        </div>
      )}
      
      {/* 病例详情弹窗 */}
      {selectedRecord && (
        <div className="detail-modal">
          <div className="modal-overlay" onClick={handleCloseDetail}></div>
          <div className="modal-content">
            <div className="modal-header">
              <h3>病例详情</h3>
              <button className="close-button" onClick={handleCloseDetail}>&times;</button>
            </div>
            
            <div className="modal-body">
              <div className="detail-section">
                <h4>基本信息</h4>
                <p><strong>医生:</strong> {selectedRecord.doctorName}</p>
                <p><strong>科室:</strong> {selectedRecord.department}</p>
                <p><strong>就诊日期:</strong> {formatDate(selectedRecord.visitDate)}</p>
              </div>
              
              <div className="detail-section">
                <h4>病情描述</h4>
                <p>{selectedRecord.symptoms}</p>
              </div>
              
              <div className="detail-section">
                <h4>体格检查</h4>
                <p>{selectedRecord.examination}</p>
              </div>
              
              <div className="detail-section">
                <h4>诊断结果</h4>
                <p>{selectedRecord.diagnosis}</p>
              </div>
              
              <div className="detail-section">
                <h4>治疗方案</h4>
                <pre>{selectedRecord.treatment}</pre>
              </div>
              
              <div className="detail-section">
                <h4>医嘱建议</h4>
                <p>{selectedRecord.advice}</p>
              </div>
              
              <div className="detail-section">
                <h4>医生备注</h4>
                <p>{selectedRecord.doctorNotes}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicalRecords;
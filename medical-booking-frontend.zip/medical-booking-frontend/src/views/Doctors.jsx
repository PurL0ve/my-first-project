import React, { useState, useEffect } from 'react';
import { getDoctors } from '../services/doctor';
import './Doctors.css';

const Doctors = () => {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [department, setDepartment] = useState('');
  const [departments] = useState([
    '内科', '外科', '儿科', '妇产科', '眼科', '耳鼻喉科', '口腔科', '皮肤科', '精神科', '中医科'
  ]);
  
  // 获取医生列表
  useEffect(() => {
    const fetchDoctors = async () => {
      setLoading(true);
      try {
        const params = {};
        if (searchTerm) params.search = searchTerm;
        if (department) params.department = department;
        
        const response = await getDoctors(params);
        setDoctors(response.data || []);
      } catch (error) {
        console.error('获取医生列表失败:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDoctors();
  }, [searchTerm, department]);
  
  const handleSearch = (e) => {
    e.preventDefault();
    // 搜索逻辑已在useEffect中处理
  };
  
  return (
    <div className="doctors-container">
      <h2>医生列表</h2>
      
      {/* 搜索和筛选表单 */}
      <form onSubmit={handleSearch} className="search-form">
        <div className="form-group">
          <input
            type="text"
            placeholder="搜索医生姓名或专长"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="form-group">
          <select value={department} onChange={(e) => setDepartment(e.target.value)}>
            <option value="">全部科室</option>
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="search-button">搜索</button>
      </form>
      
      {/* 医生列表 */}
      {loading ? (
        <div className="loading">加载中...</div>
      ) : (
        <div className="doctors-list">
          {doctors.length > 0 ? (
            doctors.map(doctor => (
              <div key={doctor.id} className="doctor-card">
                <div className="doctor-info">
                  <h3>{doctor.name}</h3>
                  <p className="department">{doctor.department}</p>
                  <p className="title">{doctor.title}</p>
                  <p className="specialty">专长: {doctor.specialty}</p>
                </div>
                <div className="doctor-actions">
                  <a href={`/appointment?doctorId=${doctor.id}`} className="appointment-button">
                    立即预约
                  </a>
                </div>
              </div>
            ))
          ) : (
            <div className="no-results">没有找到符合条件的医生</div>
          )}
        </div>
      )}
    </div>
  );
};

export default Doctors;
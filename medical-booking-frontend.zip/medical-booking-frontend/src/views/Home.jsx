import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  return (
    <div className="home-container">
      <h1>欢迎使用社区医疗中心系统</h1>
      <p className="subtitle">便捷、高效的医疗服务平台</p>
      
      <div className="features">
        <Link to="/appointment" className="feature-link">
          <div className="feature-card">
            <h3>在线预约</h3>
            <p>轻松预约医生，避免排队等待</p>
          </div>
        </Link>
        
        <Link to="/doctors" className="feature-link">
          <div className="feature-card">
            <h3>医生团队</h3>
            <p>专业的医疗团队为您提供服务</p>
          </div>
        </Link>
        
        <Link to="/queue" className="feature-link">
          <div className="feature-card">
            <h3>排队叫号</h3>
            <p>实时查看排队状态，合理安排时间</p>
          </div>
        </Link>
        
        <Link to="/medical-records" className="feature-link">
          <div className="feature-card">
            <h3>病例查询</h3>
            <p>随时查看您的医疗记录和就诊信息</p>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Home;
import React, { useState, useEffect } from 'react';
import { getQueueStatus, getUserQueueInfo } from '../services/queue';
import './QueueStatus.css';

const QueueStatus = () => {
  const [queueData, setQueueData] = useState(null);
  const [userQueueInfo, setUserQueueInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [departmentId, setDepartmentId] = useState('');
  const [departments] = useState([
    { id: '1', name: '内科' },
    { id: '2', name: '外科' },
    { id: '3', name: '儿科' },
    { id: '4', name: '妇产科' },
    { id: '5', name: '眼科' },
    { id: '6', name: '耳鼻喉科' },
    { id: '7', name: '口腔科' },
    { id: '8', name: '皮肤科' },
    { id: '9', name: '精神科' },
    { id: '10', name: '中医科' }
  ]);
  
  // 从URL获取预约ID
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const appointmentId = urlParams.get('appointmentId');
    if (appointmentId) {
      fetchUserQueueInfo(appointmentId);
    }
  }, []);
  
  // 获取用户排队信息
  const fetchUserQueueInfo = async (id) => {
    setLoading(true);
    try {
      const data = await getUserQueueInfo(id);
      setUserQueueInfo(data);
      if (data?.departmentId) {
        setDepartmentId(data.departmentId);
        fetchQueueStatus(data.departmentId);
      }
    } catch (error) {
      console.error('获取用户排队信息失败:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // 获取科室排队状态
  const fetchQueueStatus = async (id) => {
    setLoading(true);
    try {
      // 在实际应用中，这里应该从API获取真实数据
      // const data = await getQueueStatus(id);
      
      // 模拟数据
      const mockData = {
        departmentName: departments.find(dept => dept.id === id)?.name || '未知科室',
        currentNumber: Math.floor(Math.random() * 20) + 1,
        totalNumber: Math.floor(Math.random() * 50) + 20,
        averageWaitingTime: Math.floor(Math.random() * 30) + 15
      };
      
      setQueueData(mockData);
    } catch (error) {
      console.error('获取排队状态失败:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleDepartmentChange = (e) => {
    const id = e.target.value;
    setDepartmentId(id);
    if (id) {
      fetchQueueStatus(id);
    } else {
      setQueueData(null);
    }
  };
  
  return (
    <div className="queue-status-container">
      <h2>排队叫号</h2>
      
      {/* 科室选择 */}
      <div className="department-selector">
        <label htmlFor="department">选择科室</label>
        <select
          id="department"
          value={departmentId}
          onChange={handleDepartmentChange}
        >
          <option value="">请选择科室</option>
          {departments.map(dept => (
            <option key={dept.id} value={dept.id}>{dept.name}</option>
          ))}
        </select>
      </div>
      
      {/* 排队信息展示 */}
      {loading ? (
        <div className="loading">加载中...</div>
      ) : queueData ? (
        <div className="queue-info">
          <div className="queue-header">
            <h3>{queueData.departmentName}</h3>
            <div className="current-number">
              当前叫号: <span className="number">{queueData.currentNumber}</span>
            </div>
          </div>
          
          <div className="queue-details">
            <div className="detail-item">
              <span className="label">等候人数:</span>
              <span className="value">{queueData.totalNumber - queueData.currentNumber}</span>
            </div>
            <div className="detail-item">
              <span className="label">预计等待时间:</span>
              <span className="value">{queueData.averageWaitingTime} 分钟</span>
            </div>
          </div>
          
          {/* 用户排队信息 */}
          {userQueueInfo && (
            <div className="user-queue-info">
              <h4>您的排队信息</h4>
              <p><strong>排队号:</strong> {userQueueInfo.queueNumber}</p>
              <p><strong>前方等待:</strong> {userQueueInfo.aheadCount} 人</p>
              <p><strong>预计就诊时间:</strong> {userQueueInfo.expectedTime}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="no-data">请选择科室查看排队信息</div>
      )}
    </div>
  );
};

export default QueueStatus;
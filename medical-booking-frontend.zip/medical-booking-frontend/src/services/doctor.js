import request from '../utils/request';

// 模拟医生数据 - 为每个科室添加至少一名医生
const mockDoctors = [
  // 内科医生
  {
    id: '1',
    name: '张医生',
    department: '内科',
    title: '主任医师',
    specialty: '消化系统疾病、胃肠疾病',
    experience: '20年临床经验',
    description: '擅长各类消化系统疾病的诊断与治疗，尤其在胃肠疾病方面有丰富经验。'
  },
  {
    id: '2',
    name: '王医生',
    department: '内科',
    title: '副主任医师',
    specialty: '心血管疾病、高血压',
    experience: '15年临床经验',
    description: '专注于心血管疾病的预防与治疗，对高血压、冠心病等病症有深入研究。'
  },
  
  // 外科医生
  {
    id: '3',
    name: '李医生',
    department: '外科',
    title: '主任医师',
    specialty: '普通外科手术',
    experience: '18年临床经验',
    description: '精通各类普通外科手术，在疝气修补、胆囊切除等手术方面有丰富经验。'
  },
  
  // 儿科医生
  {
    id: '4',
    name: '赵医生',
    department: '儿科',
    title: '副主任医师',
    specialty: '儿童常见病、多发病',
    experience: '12年临床经验',
    description: '专注于儿童常见病的诊治，尤其擅长呼吸系统和消化系统疾病的治疗。'
  },
  
  // 妇产科医生
  {
    id: '5',
    name: '陈医生',
    department: '妇产科',
    title: '主任医师',
    specialty: '产科、妇科疾病',
    experience: '20年临床经验',
    description: '擅长产科护理和妇科疾病治疗，在孕期保健方面有丰富经验。'
  },
  
  // 眼科医生
  {
    id: '6',
    name: '刘医生',
    department: '眼科',
    title: '副主任医师',
    specialty: '白内障、青光眼',
    experience: '15年临床经验',
    description: '专注于白内障和青光眼的诊断与治疗，精通眼科手术。'
  },
  
  // 耳鼻喉科医生
  {
    id: '7',
    name: '黄医生',
    department: '耳鼻喉科',
    title: '主任医师',
    specialty: '中耳炎、鼻窦炎',
    experience: '18年临床经验',
    description: '擅长耳鼻喉常见病的诊治，尤其在中耳炎和鼻窦炎的治疗方面有丰富经验。'
  },
  
  // 口腔科医生
  {
    id: '8',
    name: '周医生',
    department: '口腔科',
    title: '副主任医师',
    specialty: '龋齿修复、根管治疗',
    experience: '14年临床经验',
    description: '专注于口腔疾病的治疗，精通龋齿修复和根管治疗技术。'
  },
  
  // 皮肤科医生
  {
    id: '9',
    name: '吴医生',
    department: '皮肤科',
    title: '主任医师',
    specialty: '过敏性皮炎、湿疹',
    experience: '20年临床经验',
    description: '擅长各类皮肤病的诊治，尤其在过敏性皮炎和湿疹的治疗方面有深入研究。'
  },
  
  // 精神科医生
  {
    id: '10',
    name: '郑医生',
    department: '精神科',
    title: '副主任医师',
    specialty: '抑郁症、焦虑症',
    experience: '15年临床经验',
    description: '专注于常见精神疾病的诊断与治疗，在心理健康领域有丰富经验。'
  },
  
  // 中医科医生
  {
    id: '11',
    name: '钱医生',
    department: '中医科',
    title: '主任医师',
    specialty: '中医内科、针灸治疗',
    experience: '25年临床经验',
    description: '擅长中医辨证施治，运用中药和针灸治疗各类疾病，尤其在慢性病调理方面有专长。'
  }
];

// 导入医生数据到本地存储
export const importDoctors = () => {
  localStorage.setItem('doctors', JSON.stringify(mockDoctors));
  return mockDoctors;
};

// 确保医生数据已导入
const ensureDoctorsData = () => {
  const storedDoctors = localStorage.getItem('doctors');
  if (!storedDoctors) {
    importDoctors();
  }
};

// 初始化时确保数据存在
ensureDoctorsData();

// 获取医生列表
export const getDoctors = async (params = {}) => {
  try {
    // 尝试从API获取数据（移除/api前缀）
    const response = await request.get('/doctors', { params });
    return response;
  } catch (error) {
    console.log('使用模拟数据显示医生列表');
    // 模拟数据逻辑保持不变
    const storedDoctors = JSON.parse(localStorage.getItem('doctors') || '[]');
    
    let filteredDoctors = storedDoctors;
    if (params.department) {
      filteredDoctors = filteredDoctors.filter(doctor => 
        doctor.department === params.department
      );
    }
    
    if (params.search) {
      const searchLower = params.search.toLowerCase();
      filteredDoctors = filteredDoctors.filter(doctor => 
        doctor.name.toLowerCase().includes(searchLower) ||
        doctor.specialty.toLowerCase().includes(searchLower) ||
        doctor.description.toLowerCase().includes(searchLower)
      );
    }
    
    return { data: filteredDoctors };
  }
};

// 获取医生详情
export const getDoctorDetail = async (id) => {
  try {
    // 尝试从API获取数据（移除/api前缀）
    const response = await request.get(`/doctors/${id}`);
    return response;
  } catch (error) {
    console.log('使用模拟数据显示医生详情');
    // 模拟数据逻辑保持不变
    const storedDoctors = JSON.parse(localStorage.getItem('doctors') || '[]');
    const doctor = storedDoctors.find(d => d.id === id);
    
    if (!doctor) {
      throw new Error('未找到该医生');
    }
    
    // 存储当前选择的医生信息，用于预约时使用
    localStorage.setItem('current_doctor_name', doctor.name);
    localStorage.setItem('current_doctor_department', doctor.department);
    
    return doctor;
  }
};
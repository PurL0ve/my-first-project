import request from '../utils/request';

// 获取排队状态
export const getQueueStatus = async (departmentId) => {
  try {
    const response = await request.get(`/api/queue/status/${departmentId}`);
    return response;
  } catch (error) {
    console.error('获取排队状态失败:', error);
    throw error;
  }
};

// 获取用户排队信息
export const getUserQueueInfo = async (appointmentId) => {
  try {
    const response = await request.get(`/api/queue/user/${appointmentId}`);
    return response;
  } catch (error) {
    console.error('获取用户排队信息失败:', error);
    throw error;
  }
};
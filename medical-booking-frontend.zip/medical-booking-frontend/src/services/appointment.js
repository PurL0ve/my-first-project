import request from '../utils/request';

// 模拟预约数据存储键名
const MOCK_APPOINTMENTS_KEY = 'mock_appointments';

// 创建预约
export const createAppointment = async (data) => {
  try {
    // 尝试从API获取数据
    const response = await request.post('/appointments', data);
    return response;
  } catch (error) {
    console.log('使用模拟数据创建预约');
    
    // 如果API请求失败，使用本地存储模拟创建预约
    const mockAppointments = JSON.parse(localStorage.getItem(MOCK_APPOINTMENTS_KEY) || '[]');
    
    // 创建模拟预约数据
    const newAppointment = {
      id: Date.now().toString(), // 使用时间戳作为唯一ID
      ...data,
      status: 'pending',
      createdAt: new Date().toISOString(),
      // 添加一些模拟数据
      doctorName: localStorage.getItem('current_doctor_name') || '医生',
      department: localStorage.getItem('current_doctor_department') || '科室'
    };
    
    mockAppointments.push(newAppointment);
    localStorage.setItem(MOCK_APPOINTMENTS_KEY, JSON.stringify(mockAppointments));
    
    return { success: true, data: newAppointment };
  }
};

// 获取用户预约列表
export const getUserAppointments = async (params = {}) => {
  try {
    // 尝试从API获取数据
    const response = await request.get('/appointments/user', { params });
    return response;
  } catch (error) {
    console.log('使用模拟数据获取预约列表');
    
    // 如果API请求失败，使用本地存储的模拟数据
    const mockAppointments = JSON.parse(localStorage.getItem(MOCK_APPOINTMENTS_KEY) || '[]');
    return { data: mockAppointments };
  }
};

// 取消预约
export const cancelAppointment = async (id) => {
  try {
    // 尝试从API获取数据
    const response = await request.put(`/appointments/${id}/cancel`);
    return response;
  } catch (error) {
    console.log('使用模拟数据取消预约');
    
    // 如果API请求失败，使用本地存储的模拟数据
    const mockAppointments = JSON.parse(localStorage.getItem(MOCK_APPOINTMENTS_KEY) || '[]');
    const updatedAppointments = mockAppointments.map(appointment => 
      appointment.id === id ? { ...appointment, status: 'canceled' } : appointment
    );
    
    localStorage.setItem(MOCK_APPOINTMENTS_KEY, JSON.stringify(updatedAppointments));
    return { success: true };
  }
};
import request from '../utils/request';

// 用户登录
export const login = async (data) => {
  try {
    const response = await request.post('/auth/login', data);
    // 保存token和用户信息
    if (response.token) {
      localStorage.setItem('token', response.token);
      localStorage.setItem('userInfo', JSON.stringify(response.userInfo));
    }
    return response;
  } catch (error) {
    console.error('登录失败:', error);
    throw error;
  }
};

// 用户注册
export const register = async (data) => {
  try {
    const response = await request.post('/auth/register', data);
    return response;
  } catch (error) {
    console.error('注册失败:', error);
    throw error;
  }
};

// 获取用户信息
export const getUserInfo = async () => {
  try {
    const response = await request.get('/auth/userInfo');
    // 更新本地存储的用户信息
    localStorage.setItem('userInfo', JSON.stringify(response));
    return response;
  } catch (error) {
    console.error('获取用户信息失败:', error);
    throw error;
  }
};

// 更新用户信息
export const updateUserInfo = async (data) => {
  try {
    const response = await request.put('/auth/userInfo', data);
    // 更新本地存储的用户信息
    localStorage.setItem('userInfo', JSON.stringify(response));
    return response;
  } catch (error) {
    console.error('更新用户信息失败:', error);
    throw error;
  }
};

// 用户登出
export const logout = async () => {
  try {
    await request.post('/auth/logout');
    // 清除本地存储的token和用户信息
    localStorage.removeItem('token');
    localStorage.removeItem('userInfo');
    // 清除其他可能的用户相关数据
    localStorage.removeItem('doctors');
    localStorage.removeItem('mock_appointments');
    localStorage.removeItem('current_doctor_name');
    localStorage.removeItem('current_doctor_department');
    // 重定向到登录页面
    window.location.href = '/login';
    return true;
  } catch (error) {
    console.error('登出失败:', error);
    // 即使请求失败，也清除本地存储的token和用户信息
    localStorage.removeItem('token');
    localStorage.removeItem('userInfo');
    localStorage.removeItem('doctors');
    localStorage.removeItem('mock_appointments');
    localStorage.removeItem('current_doctor_name');
    localStorage.removeItem('current_doctor_department');
    // 重定向到登录页面
    window.location.href = '/login';
    return false;
  }
};
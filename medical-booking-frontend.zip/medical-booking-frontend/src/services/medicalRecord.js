import request from '../utils/request';

// 获取用户病例列表
export const getUserMedicalRecords = async (params = {}) => {
  try {
    const response = await request.get('/api/medical-records/user', { params });
    return response;
  } catch (error) {
    console.error('获取用户病例列表失败:', error);
    throw error;
  }
};

// 获取病例详情
export const getMedicalRecordDetail = async (id) => {
  try {
    const response = await request.get(`/api/medical-records/${id}`);
    return response;
  } catch (error) {
    console.error('获取病例详情失败:', error);
    throw error;
  }
};
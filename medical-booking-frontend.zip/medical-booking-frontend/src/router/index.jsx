import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from '../components/Layout/Layout';
import Home from '../views/Home';
import Login from '../components/Auth/Login';
import Register from '../components/Auth/Register';
import UserInfo from '../views/UserInfo';
import Doctors from '../views/Doctors';
import Appointment from '../views/Appointment';
import MyAppointments from '../views/MyAppointments';
import QueueStatus from '../views/QueueStatus';
import MedicalRecords from '../views/MedicalRecords';
import NotFound from '../views/NotFound';

// 检查是否登录的函数
const isAuthenticated = () => {
  return !!localStorage.getItem('token');
};

// 受保护的路由组件
const ProtectedRoute = ({ children }) => {
  if (!isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const Router = () => {
  return (
    <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* 使用布局组件的路由 */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }>
          <Route index element={<Home />} />
          <Route path="user" element={<UserInfo />} />
          <Route path="doctors" element={<Doctors />} />
          <Route path="appointment" element={<Appointment />} />
          <Route path="my-appointments" element={<MyAppointments />} />
          <Route path="queue" element={<QueueStatus />} />
          <Route path="medical-records" element={<MedicalRecords />} />
        </Route>
        
        {/* 404页面 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Router;
import React, { useState } from 'react';
import { login } from '../../services/auth';
import './Auth.css';

const Login = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await login(formData);
      // 登录成功后跳转到首页
      window.location.href = '/';
    } catch (err) {
      setError(err.response?.data?.message || '登录失败，请检查用户名和密码');
    } finally {
      setLoading(false);
    }
  };

  // 模拟内部账号登录（不依赖后端API）
  const handleInternalAccountLogin = () => {
    // 直接在前端设置模拟的token和用户信息
    const mockToken = 'internal_test_token';
    const mockUserInfo = {
      id: 1,
      username: 'admin',
      phone: '13800138000',
      email: 'admin@example.com',
      role: 'admin'
    };
    
    // 保存到本地存储
    localStorage.setItem('token', mockToken);
    localStorage.setItem('userInfo', JSON.stringify(mockUserInfo));
    
    // 跳转到首页
    window.location.href = '/';
  };

  return (
    <div className="auth-container">
      <div className="auth-form">
        <h2>用户登录</h2>
        {error && <div className="error-message">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">用户名</label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              placeholder="请输入用户名"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">密码</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="请输入密码"
              required
            />
          </div>
          <button type="submit" className="submit-button" disabled={loading}>
            {loading ? '登录中...' : '登录'}
          </button>
        </form>
        {/* 内部账号登录按钮 */}
        <button 
          type="button" 
          className="test-account-button"
          onClick={handleInternalAccountLogin}
          style={{
            width: '100%',
            padding: '12px',
            marginTop: '10px',
            backgroundColor: '#2196F3',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '16px'
          }}
        >
          使用内部账号直接登录
        </button>
        <div className="register-link">
          还没有账号？ <a href="/register">立即注册</a>
        </div>
      </div>
    </div>
  );
};

export default Login;
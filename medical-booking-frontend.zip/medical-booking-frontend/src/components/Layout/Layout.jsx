import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { logout } from '../../services/auth';
import './Layout.css';

const Layout = () => {
  // 获取当前用户信息
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  
  const handleLogout = () => {
    logout();
  };
  
  return (
    <div className="layout">
      {/* 顶部导航栏 */}
      <header className="header">
        <div className="logo">社区医疗中心系统</div>
        <nav className="nav">
          <Link to="/">首页</Link>
          <Link to="/doctors">医生列表</Link>
          <Link to="/appointment">预约挂号</Link>
          <Link to="/my-appointments">我的预约</Link>
          <Link to="/queue">排队叫号</Link>
          <Link to="/medical-records">病例查询</Link>
        </nav>
        <div className="user-info">
          <span>欢迎，{userInfo.username || '用户'}</span>
          <Link to="/user">个人中心</Link>
          <button onClick={handleLogout} className="logout-btn">退出登录</button>
        </div>
      </header>
      
      {/* 主要内容区域 */}
      <main className="main">
        <Outlet />
      </main>
      
      {/* 页脚 */}
      <footer className="footer">
        <p>© 2023 社区医疗中心系统 版权所有</p>
      </footer>
    </div>
  );
};

export default Layout;